import os
import pandas as pd
import streamlit as st
import chromadb as cdb
from chromadb.config import Settings, DEFAULT_TENANT
from streamlit_dimensions import st_dimensions
import altair as alt
from utils.util import storage_stat as ss
from utils.config_util import config
from utils.util import model_util as mu


# https://www.color-hex.com/color-palette/164
colors = ['#6d765b','#A5BFA6']#['#847577','#cfd2cd']#['#f07162','#0081a7']#['#f97171','#8ad6cc']
#["#ae5a41", "#1b85b8"]#["#636B2F","#BAC095"] #["#9EB8A0", "#58855c"]#['#58855c','#0D3311']#["#BAC095", "#636B2F"]

'''
altair==5.5.0
chromadb==0.5.3  --0.6.3
#country_converter==1.3.2
#fastparquet==2025.12.0
geopy==2.4.1
GPSPhoto==2.2.3
matplotlib==3.10.5 #3.10.8
numpy==1.26.4
pandas==2.2.2
piexif==1.1.3
Pillow==10.1.0   #12.1.1
PyYAML==6.0.3
scikit_learn==1.5.0

# streamlit==1.55.0
# streamlit_dimensions==0.0.1
# streamlit_extras==0.7.8
# streamlit_image_select==0.6.0

#
streamlit==1.39.0
streamlit-aggrid==1.2.1.post2
streamlit-avatar==0.1.3
streamlit-camera-input-live==0.2.0
streamlit-card==1.0.2
streamlit-dimensions==0.0.1
streamlit-embedcode==0.1.2
streamlit-extras==0.6.0
streamlit-image-coordinates==0.1.9
streamlit-image-select==0.6.0
streamlit-keyup==0.3.0
streamlit-option-menu==0.4.0
streamlit-toggle-switch==1.0.2
streamlit-tree-select==0.0.5
streamlit-vertical-slider==2.5.5
streamlit_faker==0.0.4
streamlit_folium==0.22.1
streamlit_imagegrid==0.0.7

#
torch==2.2.2
open-clip-torch==2.24.0
#tqdm==4.67.3

app launcher linux mint
-----------------------
ok changes .local python3 libraries
[Desktop Entry]
Name=zMedia
Exec=/home/madhekar/.local/bin/zmedia\n
Comment=zesha media browser application
Terminal=true
PrefersNonDefaultGPU=true
Icon=cinnamon-panel-launcher
Type=Application

good - isolated python3 libraries
[Desktop Entry]
Name=zm
Exec=./.zmedia/bin/zmedia
Comment=zmedia app launcher
Terminal=true
PrefersNonDefaultGPU=true
Icon=cinnamon-panel-launcher
Type=Application
'''

def extract_folder_paths():
    (
    data_path, 
    raw_data_path, 
    vectordb_path,
    image_collection_name,
    video_collection_name,
    text_collection_name,
    audio_collection_name,
    final_image_data_path, 
    final_video_data_path, 
    final_audio_data_path, 
    final_text_data_path
    ) = (
        config.overview_config_load()
    )
    ovr_path_list = [final_image_data_path, final_video_data_path, final_text_data_path, final_audio_data_path]
    vdb_list = [vectordb_path, image_collection_name, text_collection_name, video_collection_name,  audio_collection_name]

    return (data_path, raw_data_path, vdb_list, ovr_path_list)


def get_vdb_connection(vdb_path):
    client = None
    try:
      client = cdb.PersistentClient(vdb_path, tenant=DEFAULT_TENANT, settings=Settings(allow_reset=False))
      print(f"number of collections found: {client.count_collections()}")  
    except Exception as e:
        print(f"exception occurred getting vdb client connection: {e}")  
    return client    

def get_collection_record_count(vdb_list):

    vdb_path =  vdb_list.pop(0)

    print(vdb_list)

    client = get_vdb_connection(vdb_path)

    collection_count = []
   
    for c in vdb_list: 
        try:
            cc = client.get_collection(name=c)
            val = cc.count()
            collection_count.append({"modality": c.removeprefix("multimodal_collection_"), 'count': val})
        except Exception as e:
            print(f"exception occurred while getting collection: {c} as: {e}")    
            collection_count.append({"modality": c.removeprefix("multimodal_collection_"), 'count': 0})
            continue
    print(collection_count)    
    return  collection_count    


def disc_usage_1(tm, um, fm, w):
    #v = w["width"]
    mem = pd.DataFrame({"disc": ["Total", "Used", "Free"], "size": [tm, um, fm]})

    bar = (
        alt.Chart(mem)
        .mark_bar(opacity=0.7)
        .encode(
            y=alt.Y("size:Q", axis=alt.Axis(grid=True, gridColor="grey"), title="Disc Storage Size in GB"),
            x=alt.X("disc:N", axis=alt.Axis(grid=True, gridColor="grey"), title="Disc Storage Category"),
            color=alt.Color("disc:N", scale=alt.Scale( scheme='dark2'), legend= None ) #alt.Legend(labelFontWeight="bold",labelColor="black", labelFontSize=20))#range=['#5A86AD', '#A3B18A', '#C17C74']))
        )
    )
    text = bar.mark_text(
        align="center",
        baseline="middle",
        dy=-5,
        fontWeight="bold",
        color="black"
    ).encode(text="size")

    st.altair_chart(bar + text, use_container_width=True)


def disc_usage(tm, um, fm,w):

    v = w['width'] if w is not None else 400
    mem = pd.DataFrame({"disc": ["Total", "Used", "Free"], "size": [tm, um, fm]})

    # This formats the value as an integer for cleaner presentation in the legend/tooltip
    mem["legend_label"] = (mem["disc"] + ":" + mem["size"].astype(str) + "GB")

    # Encode theta by the value, and color by the new combined label
    base = alt.Chart(mem).encode(
        theta=alt.Theta("size:Q").stack(True),
        radius=alt.Radius("size").scale(type="linear", zero=True),
        color=alt.Color("size:Q", scale=alt.Scale(scheme="dark2"), legend=None)
    )

   # 4. Create the pie (arc) layer innerRadius=int(0.05 * v), outerRadius=int(0.2 * v)
    pie = base.mark_arc(opacity=0.7, innerRadius=int(.2 * v), outerRadius=int(.7 * v), stroke="#fff").encode(
        tooltip=["disc:N", "size:Q", alt.Tooltip("legend_label:N")],
        
    )
    text = base.mark_text(align='center', radiusOffset=10, color="black").encode(text="size:Q")
    st.altair_chart(pie + text, use_container_width=True)


def display_storage_metrics(tm, um, fm, ld):
    c1,  c2 = st.columns([0.5,  0.5])
    with c1:
        #st.markdown('<p class="vertical-text">DISK usage</p>', unsafe_allow_html=True)
        #st.markdown("""##### <span style='color:#2d4202'><u>DISK usage</u></span>""",unsafe_allow_html=True)  
        st.write("***disk usage***")      
        width = st_dimensions(key="c1_width")
        disc_usage(tm, um, fm, width)

    with c2:
        st.write("***records per modality***") 
        #images = [{"modality": "Images", "count": 580},{"modality": "Documents", "count": 1020},{"modality": "Videos", "count": 1600},{"modality": "Audios", "count": 100}]
        df = pd.DataFrame(ld)
        print(df)
        base = alt.Chart(df).encode(
            x='modality:N',
            y="count:Q",
            text='count',
            color='modality:N'
        )
        ch = base.mark_bar() + base.mark_text(align='center', dy=-10)
        st.altair_chart(ch, use_container_width=True)

def execute():

        data_path, final_data_path, vdb_list, opl = extract_folder_paths() 

        ld = get_collection_record_count(vdb_list=vdb_list)
    
        efs = ss.extract_user_raw_data_folders(final_data_path)

        st.sidebar.markdown('##### :blue[**DATA SOURCES**]')
        for ds in efs:
                st.sidebar.write(f'**{ds}**')
        st.sidebar.divider()        
        st.sidebar.markdown('</div>', unsafe_allow_html=True)   
        
        display_storage_metrics(*ss.extract_server_stats(), ld) #, dfi, dff)


if __name__ == "__main__":
    execute()
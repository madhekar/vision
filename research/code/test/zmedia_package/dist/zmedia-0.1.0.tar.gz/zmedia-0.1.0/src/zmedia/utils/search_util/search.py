import os
import streamlit as st
import platform
from pathlib import WindowsPath
import datetime
import pandas as pd
import ast

# from streamlit_option_menu import option_menu
from streamlit_image_select import image_select
from utils.config_util import config
import PIL
from PIL import Image, ImageOps
from chromadb.utils.embedding_functions import OpenCLIPEmbeddingFunction
from streamlit_extras.mandatory_date_range import date_range_picker as drp

import chromadb as cdb
from chromadb.utils.embedding_functions import OpenCLIPEmbeddingFunction
from chromadb.utils.data_loaders import ImageLoader
from chromadb.config import Settings, DEFAULT_TENANT
from utils.util import file_type_ext as fte
from utils.util import chroma_util as cu

PIL.Image.MAX_IMAGE_PIXELS = 933120000
MIN_DT = datetime.datetime(1998, 1, 1)
MAX_DT = datetime.datetime.now()


@st.cache_resource(show_spinner=True)
def init_vdb(vdp, icn, tcn, vcn):
    # vector database persistance
    client = cdb.PersistentClient( path=vdp, tenant=DEFAULT_TENANT, settings=Settings(allow_reset=False))
    
    # openclip embedding function!
    embedding_function = OpenCLIPEmbeddingFunction()
    #text_embedding_function = OpenCLIPEmbeddingFunction(model_name="coca_roberta-ViT-B-32") 

    # Image collection inside vector database 'chromadb'
    image_loader = ImageLoader()

    # collection images defined
    collection_images = client.get_or_create_collection(
      name=icn, 
      embedding_function=embedding_function, 
      metadata={"hnsw:space": "cosine"},
      data_loader=image_loader
      )
    
    collection_videos = client.get_or_create_collection(
           name=vcn,
           embedding_function=embedding_function,
            metadata={"hnsw:space": "cosine"},
            data_loader=image_loader,
        )
    
    #Text collection inside vector database 'chromadb'
    collection_text = client.get_or_create_collection(
      name=tcn,
      metadata={"hnsw:space": "cosine"},
      embedding_function=embedding_function,
    )

    #print("*****", collection_text.peek())
    return client, collection_images, collection_text, collection_videos

def updateMetadata(client, image_collection,  id, desc, names, dt, loc):
    # vector database persistance
    #client = cdb.PersistentClient(path=storage_path, settings=Settings(allow_reset=True))
    col = client.get_collection(image_collection)
    col.update(
        ids=id,
        metadatas={"description": desc, "names": names, "datetime" : dt, "location": loc}
    )

def os_specific_path(img_path):
    linux_prefix = "/mnt/zmdata/"
    mac_prefix = "/Users/Share/zmdata/"
    win_prefix = "c:/Users/Public/zmdata/"
    token = "home-media-app"
    n_pth = ""

    platform_system = platform.system()

    # Example of conditional logic based on OS
    if platform_system == "Windows":
        w_img_path = WindowsPath(img_path)
        parts = w_img_path.split(token,1)
        if len(parts) > 1:
            n_pth = win_prefix + token + parts[1]
        

    elif platform_system == "Linux":
        parts = img_path.split(token,1)
        if len(parts) > 1:
            n_pth = linux_prefix + token + parts[1]
        

    elif platform_system == "Darwin":
        parts = img_path.split(token,1)
        print(parts)
        if len(parts) > 1:
            n_pth = mac_prefix + token + parts[1]

    return n_pth    

def search_fn(client, cImgs, cTxts, cVideos):
    # create default application Tabs
    image, video, text = st.tabs(["Image", "Video", "Text"])

    # init session variables
    if "document" not in st.session_state:
        st.session_state["document"] = []

    if "t_imgs" not in st.session_state:
        st.session_state["t_imgs"] = []

    if "t_videos" not in st.session_state:
        st.session_state["t_videos"] = []    

    if "meta" not in st.session_state:
        st.session_state["meta"] = []

    if "vmeta" not in st.session_state:
        st.session_state["vmeta"] = []    

    if "llm_text" not in st.session_state:
        st.session_state["llm_text"] = st.empty()

    if "imgs" not in st.session_state:
        st.session_state["imgs"] = []

    if "videos" not in st.session_state:
        st.session_state["videos"] = []    

    if "dt_range" not in st.session_state:
        st.session_state["dt_range"] = (
            datetime.datetime(2010, 1, 1),
            datetime.datetime(2025, 1, 1),
        )

    # define application sidebar
    with st.sidebar:

        modality_selected = st.selectbox(
            label="## Search Modality",
            options=("text", "image"),
            index=1,
            help="select search modality type",
        )

        st.divider()

        multi_modality_select = st.multiselect(
            label="## Show Modalities",
            options=["image", "text", "video", "audio"],
            default=["image", "text"],
            help="select one or more search result modalities",
        )

        st.divider()

        if modality_selected == "image":
            similar_image = st.file_uploader(
                label="## Select Image",
                label_visibility="hidden",
                type= fte.image_types, #["png", "jpeg", "mpg", "jpg", "PNG", "JPG", "JPEG", "MPG"],
                help="select image to search similar images",
            )
            im = st.empty()
            if similar_image:
                im = Image.open(similar_image)
                name = similar_image.name
                st.sidebar.image(im, caption="")
                # st.sidebar.write(st.session_state["llm_text"])
                with open(name, "wb") as f:
                    f.write(similar_image.getbuffer())
        elif modality_selected == "text":
            modalityTxt = st.text_input(
                label="## Search text",
                placeholder="search modality types for...",
                disabled=False,
            )
            modalityTxt = cu._preprocess_query(modalityTxt)
        st.divider()
       

        def date_change():
            st.session_state["dt_range"] = st.session_state.mySlider

        date_range = drp("select date range")
        # date_range = st.slider(
        #     label="## Date range",
        #     key="mySlider",
        #     value=st.session_state["dt_range"],
        #     min_value=MIN_DT,
        #     max_value=MAX_DT,
        #     step=datetime.timedelta(days=1),
        #     on_change=date_change,
        #     help="search result date range",
        # )

        st.divider()

        search_btn = st.button(label="## Search", use_container_width=True, type="primary")


    ''' 
    **** search button pressed **** 
    '''
    if search_btn:
        # create query on image, also shows similar document in vector database (not using LLM)  -- openclip embedding function!
        #embedding_function = OpenCLIPEmbeddingFunction()

        # reset session_state for temperory images for view
        if "t_imgs" in st.session_state:
            st.session_state["t_imgs"] = []

        if "t_videos" in st.session_state:
            st.session_state["t_videos"] = []    

        # reset session_state for metadata
        if "meta" in st.session_state:
            st.session_state["meta"] = []

        if "vmeta" in st.session_state:
            st.session_state["vmeta"] = []    

        if "document" in st.session_state:
            st.session_state["document"] = []    

        ''' 
        Image Modality selected 
        '''
        if modality_selected == "image":
            # execute text collection query --- TBD fix

            # st.session_state["document"] = cTxts.query(
            #     query_embeddings=embedding_function("./" + similar_image.name),
            #     n_results=5,
            # )["documents"][0][0]

            # get location and datetime metadata for an image
            # qmdata = util.getMetadata(sim.name)
            # dt_format = "%Y-%m-%d %H:%M:%S"
            # st.write(qmdata[3])
            # d = parser.parse(qmdata[3]).timestamp()
            # st.write(
            #    d,
            #    st.session_state["dt_range"][0].timestamp(),
            #    st.session_state["dt_range"][1].timestamp(),
            # )

            # execute image query with search criteria
            st.session_state["imgs"] = cu.rerank_image_search(os.path.join('./', similar_image.name), cImgs, rmax=100, top=30)

            #execute video query with search criteria
            st.session_state["videos"] = cu.rerank_video_search(os.path.join('./', similar_image.name), cVideos, rerank=False, rmax=100, top=30)
            print("***Videos***", st.session_state["videos"])

            ''' 
            Text Modality selected 
            ''' 
        elif modality_selected == "text":
            
            # execute text collection query --- TBD fix
            st.session_state["document"] = cTxts.query(
                query_texts=[modalityTxt],
                include=["documents", "metadatas", "distances"], 
                n_results=10,
            )

            #print(">>>>>", st.session_state["document"])
            
            st.session_state["imgs"] = cu.rerank_image_text_search(modalityTxt, cImgs, rmax=100, top=30) 

            # execute video query with search criteria
            st.session_state["videos"] = cu.rerank_video_text_search(modalityTxt, cVideos, rekank=False, rmax=20, top=10)
            print("**videos**", cVideos.count(), "***",  st.session_state["videos"]) 


        for img in st.session_state["imgs"]:
            #if img.mode in ("RGBA", "P"):
            #if img.shape[2] == 4:
                #img = img[:, :, :3]
                #img = img.convert("RGB")
            st.session_state["t_imgs"].append(img[0])

        for i, mdata in enumerate(st.session_state["imgs"]):
            #st.write(mdata) #---???
            tss =  mdata[1]["ts"] if mdata[1]["ts"]  else "1765060800.0"
            st.session_state["meta"].append(
                "Desc:["
                + mdata[1]["text"]
                # + "] ) People: ["
                # + mdata.get("names")
                + "] Location: ["
                + mdata[1]["loc"]
                + "] Date: ["
                + str(datetime.datetime.fromtimestamp(float(tss)))
                + "]"
            )

        for vmdata in st.session_state["videos"]:
            #if img.mode in ("RGBA", "P"):
            #if img.shape[2] == 4:
            #    img = img[:, :, :3]
            st.session_state["t_videos"].append(vmdata[0])

        for vmdata in st.session_state["videos"]: #["metadatas"][0][1:]:
            st.session_state["vmeta"].append(vmdata[1]["vuri"])

            #print("%%%%", st.session_state["vmeta"])
      

    '''  
    **** Image TAB ****
    '''
    with image:
        if st.session_state["t_imgs"] and len(st.session_state["t_imgs"]) > 1:
            index = image_select(
                label= "analogous images",
                images=st.session_state["t_imgs"],
                use_container_width=True,
                # captions=st.session_state["meta"],
                index=0,
                return_value="index",
            )
            # img, map = st.tabs(["Img", "Map"])
            c1, c2 = st.columns([7, 3])

            # c2.divider()
            col21, col22, col23, cole = c2.columns([1, 1, 1,1], gap="small")
            with col21:
                right = st.button(label="## &#x21B7;")
            with col22:
                left = st.button(label="## &#x21B6;")
            with col23:
                flip = st.button(label="## &#x21C5;")
            # with cole:
            #     edit = st.button(label="## &#x270D;")    

            # with img:
            im = Image.open(st.session_state["t_imgs"][index])
            # if im.mode in ("RGBA", "P"):
            #    im = im.convert("RGB")
            nim = ImageOps.expand(im, border=(2, 2, 2, 2), fill=(200, 200, 200))
            print(f"***{nim}")
            imageLoc = c1.empty()
            display_im = imageLoc.image(nim, use_column_width="always")
            # st.button(st.image(nim, use_column_width="always"))

            if right:
                nim = nim.rotate(-90)
                imageLoc.image(nim, use_column_width="always")
            if left:
                nim = nim.rotate(90)
                imageLoc.image(nim, use_column_width="always")
            if flip:
                nim = nim.rotate(180)
                imageLoc.image(nim, use_column_width="always")
            # if edit:
            #     updateMetadata(
            #         client,
            #         cImgs,
            #         id=st.session_state["imgs"]["ids"][0][index],
            #         desc=st.session_state["imgs"]["metadatas"][0][1:][index]["text"],
            #         #names=st.session_state["imgs"]["metadatas"][0][1:][index]["names"],
            #         dt=st.session_state["imgs"]["metadatas"][0][1:][index]["ts"],
            #         loc=st.session_state["imgs"]["metadatas"][0][1:][index]["loc"],
            #     )

            colt, cole = c2.columns([0.1, 0.9])
            with colt:
                st.markdown("<p class='big-font-subh'>Caption: </p>", unsafe_allow_html=True)
            with cole:
                o_caption = f'<p class="input">{st.session_state["imgs"][index][1]["caption"]}</p>'
                st.markdown(o_caption, unsafe_allow_html=True)


            colt, cole = c2.columns([0.1, 0.9])
            with colt:
                st.markdown("<p class='big-font-subh'>Desc: </p>", unsafe_allow_html=True)
            with cole:
                o_desc = f'<p class="input">{st.session_state["imgs"][index][1]["text"]}</p>'
                st.markdown(o_desc, unsafe_allow_html=True)

            colt, cole = c2.columns([0.1, 0.9])
            with colt:
               st.write("<p class='big-font-subh'>People: </p>", unsafe_allow_html=True)
            with cole:
               o_names = f'<p class="input">{st.session_state["imgs"][index][1]["ppt"]} </p>' #- {st.session_state["imgs"]["metadatas"][0][1:][index]["names"]}</p>'
               st.markdown(o_names, unsafe_allow_html=True)

            colt, cole = c2.columns([0.1, 0.9])
            with colt:
               st.write("<p class='input-subh'>Date Time: </p>", unsafe_allow_html=True)
            with cole:
                tts = "0.0" if st.session_state["imgs"][index][1]["ts"] == "" else st.session_state["imgs"][index][1]["ts"]
                o_datetime = f'<p class="input">{str(datetime.datetime.fromtimestamp(float(tts)))}</p>'
                st.markdown(o_datetime, unsafe_allow_html=True)

            colt, cole = c2.columns([0.1, 0.9])
            with colt:
                st.write("<p class='big-font-subh'>Location: </p>", unsafe_allow_html=True)
            with cole:
                o_location = f'<p class="input">{st.session_state["imgs"][index][1]["loc"]}</p>'
                st.markdown(o_location, unsafe_allow_html=True)


            ll = ast.literal_eval(st.session_state["imgs"][index][1]["latlon"])     
            lat = ll[0] 
            lon = ll[1] 

            map_data = pd.DataFrame({"lat": [lat], "lon": [lon]})
            c2.markdown("<p class='big-font-subh'>Map</p>", unsafe_allow_html=True)
            c2.map(map_data, zoom=12, size=80, color="#ff00ff")
        else:
            st.write(
                "<p class='big-font'>sorry, no similar images found in search criteria!</p>",
                unsafe_allow_html=True,
            )

    ''' 
    **** Video TAB **** 
    '''
    with video:
      if st.session_state["t_videos"] and len(st.session_state["t_videos"]) > 1: 
        index = image_select(
                    label= "Resembling Videos",
                    images=st.session_state["t_videos"],
                    use_container_width=True,
                    # captions=st.session_state["meta"],
                    index=0,
                    return_value="index",
                )
        c1, c2 = st.columns([7, 3])    

        with c1:
                 vid  = st.session_state["vmeta"][index]
                 print("$$$", vid)
                 video_file = open(vid, "rb")
                 video_bytes = video_file.read()
                 st.video(video_bytes)

        with c2:

            colt, cole = st.columns([0.1, 0.9])
            with colt:
                    st.markdown("<p class='big-font-subh'>Caption: </p>", unsafe_allow_html=True)
            with cole:
                    try:
                       o_caption = f'<p class="input">{st.session_state["videos"][index][1]["caption"]}</p>'
                       st.markdown(o_caption, unsafe_allow_html=True)
                    except Exception as e:
                        print(f"Error: {e}")
                        st.markdown("None", unsafe_allow_html=True)
            colt, cole = st.columns([0.1, 0.9])

            with colt:
                    st.markdown("<p class='big-font-subh'>Desc: </p>", unsafe_allow_html=True)
            with cole:
                    o_desc = f'<p class="input">{st.session_state["videos"][index][1]["text"]}</p>'
                    st.markdown(o_desc, unsafe_allow_html=True)


            colt, cole = st.columns([0.1, 0.9])
            with colt:
                st.write("<p class='input-subh'>Date Time: </p>", unsafe_allow_html=True)
            with cole:
                    tts = "0.0" if st.session_state["videos"][index][1]["ts"] == "" else st.session_state["videos"][index][1]["ts"]
                    o_datetime = f'<p class="input">{str(tts)}</p>' # datetime.datetime.fromtimestamp(float(tts))
                    st.markdown(o_datetime, unsafe_allow_html=True)

            colt, cole = st.columns([0.1, 0.9])
            with colt:
                    st.write("<p class='big-font-subh'>Location: </p>", unsafe_allow_html=True)
            with cole:
                    o_location = f'<p class="input">{st.session_state["videos"][index][1]["loc"]}</p>'
                    st.markdown(o_location, unsafe_allow_html=True)


                    ll = ast.literal_eval(st.session_state["videos"][index][1]["latlon"])  
                    if ll:   
                        lat = ll[0] 
                        lon = ll[1] 
                    else:
                        lat = 0.0
                        lon = 0.0    

                    map_data = pd.DataFrame({"lat": [lat], "lon": [lon]})
                    st.markdown("<p class='big-font-subh'>Map</p>", unsafe_allow_html=True)
                    st.map(map_data, zoom=12, size=80, color="#ff00ff")    
      else:    
            st.write(
                "<p class='big-font'>sorry, no similar videos found in search criteria!</p>",
                unsafe_allow_html=True,
            )

    ''' 
    **** Documents Tab **** 
    '''
    with text:

        if st.session_state["document"] and len(st.session_state["document"]["documents"][0]) > 1:
            # print(f"result---> {len(st.session_state['document']['documents'])}")
            for idx, doc in enumerate(st.session_state["document"]["documents"][0]):
                c0, c1, c2 = st.columns([.01, 0.8, 0.2])
                cnt  = idx + 1
                with c0:
                    st.write(f"**{cnt}**")
                with c1:  
                    st.text_area(label=f"{idx}", value=str(doc), label_visibility="collapsed", height=300)  #st.session_state["document"]["documents"][0][0])
                with c2:
                    name, parent = fte.get_basename_parent(st.session_state["document"]["metadatas"][0][idx]["name"])
                    colt, cole = st.columns([1,9])
                    with colt:
                        st.markdown("<p class='big-font-subh'>Doc: </p>", unsafe_allow_html=True)
                    with cole:    
                        #txt = f'**{name}**: Document found in: **{parent}**'
                        st.write(f"**{name}** found in **{parent}**", unsafe_allow_html=True)

                    colt, cole = st.columns([2,8])
                
                    with colt:
                        st.markdown("<p class='big-font-subh'>Date: </p>", unsafe_allow_html=True)
                    with cole:
                        o_desc = f'<p class="input">{st.session_state["document"]["metadatas"][0][idx]["ts"]}</p>'
                        st.markdown(o_desc, unsafe_allow_html=True)
        else:
              st.write(
                "<p class='big-font'>sorry, no similar documents found in search criteria!</p>",
                unsafe_allow_html=True,
              )


def execute():

    '''
        linux_prefix,
        mac_prefix,
        win_prefix,
        token
    '''
    vdb, icn, tcn, vcn, acn = config.search_config_load()
    print(vdb, ': ', icn,':', tcn)
    client, img_collection, txt_collection, video_collection  = init_vdb(vdb, icn, tcn, vcn)

    search_fn(client, img_collection, txt_collection, video_collection)

    

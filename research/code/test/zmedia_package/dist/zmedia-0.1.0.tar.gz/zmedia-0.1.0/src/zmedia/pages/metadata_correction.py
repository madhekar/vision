import streamlit as st
from utils.editor_util import editor as edt

st.header("METADATA: EDITOR", divider="gray")

edt.execute()
import streamlit as st
from utils.search_util import search as s

st.header("SEARCH")
s.execute()
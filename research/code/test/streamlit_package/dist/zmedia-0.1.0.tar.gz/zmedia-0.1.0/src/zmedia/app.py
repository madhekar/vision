# src/your_app_package_name/app.py
import streamlit as st

def main():
    st.title("My Streamlit App Package")
    st.write("This app is running as an installed package.")

if __name__ == "__main__":
    main()